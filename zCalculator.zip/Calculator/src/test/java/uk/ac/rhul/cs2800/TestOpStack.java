package uk.ac.rhul.cs2800;


import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.EmptyStackException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class TestOpStack {
  private OpStack opStack;
  private Symbol symbolValue;
  
  @BeforeEach
  void createOpStack() {
    opStack = new OpStack();
    symbolValue = Symbol.TIMES;
  }
  
  @Test //1st test
  void testGetSize() {
    assertTrue(opStack.getSize() == 0);
  }

  @Test //2nd test
  void testIsEmpty() {
    assertEquals(opStack.isEmpty(), true);
  }
  
  @Test //3rd test
  void testPush() {
    symbolValue = Symbol.PLUS;
    opStack.push(symbolValue);
    assertTrue(opStack.getSize() == 1);
    assertFalse(opStack.isEmpty());
  }
  
  @Test //4th test
  void testEmptyPop() throws EmptyStackException {
    assertThrows(EmptyStackException.class, () -> opStack.pop());
  }
  
  @Test //5th test
  void testPop() throws EmptyStackException, BadTypeException {
    symbolValue = Symbol.PLUS;
    opStack.push(symbolValue);
    assertTrue(opStack.getSize() == 1);
    assertEquals(opStack.pop(), Symbol.PLUS);
  }
  
  @Test //6th test
  void testEmptyTop() throws EmptyStackException, BadTypeException {
    assertThrows(EmptyStackException.class, () -> opStack.top());
  }
  
  @Test //7th test
  void testTop() throws EmptyStackException, BadTypeException {
    opStack.push(symbolValue);
    assertEquals(opStack.top(), Symbol.TIMES);
  }
}
