package uk.ac.rhul.cs2800;


import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class TestType {
  private Type number;
  
  @BeforeEach
  public void setup() {
    number = Type.NUMBER;
  }
  
  @Test //First Test
  void testTypeConstructor() {
    assertTrue(number.getType() == "Number", 
        "Test the Type Enum Constructor initialises Type Objects with the given String variable.");
  } 
  
  @Test //Second Test
  void testConstructTwice() {
    Type string = Type.STRING;
    Type invalid = Type.INVALID;
    assertFalse(string.equals(invalid), 
        "Test the Type Constructor constructs two Type objects and the two objects are equal.");
  }
  
  @Test //Third Test
  void testGetType() {
    assertEquals(number.getType(), "Number", 
        "Test that getType method returns the Type object's type value");
  }
  
  @Test //Fourth Test
  void testIsType() {
    assertTrue(Type.STRING.isType(), 
        "Test that the Object is of Enum Type.");
  }
  
  @Test //Fifth Test
  void testIsTypeNull() {
    Type nulltype = null;
    assertThrows(NullPointerException.class, () -> nulltype.isType(), 
        "Calling isType on a null object is not possible!");
  }

}
