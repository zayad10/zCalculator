package uk.ac.rhul.cs2800;


import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.EmptyStackException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class TestRevPolishCalc {
  private static RevPolishCalc calc;
  private String expr1;
  private String expr2;
  private String expr3;
  private String expr4;
  private float number;
  
  @BeforeEach
  void createRevPolishCalc() {
    calc = new RevPolishCalc();
    expr1 = "1 2 3 + - 2 *";
    expr2 = "( 3 - ( 1 * 2 ) )";
    expr3 = "";
    expr4 = "5 6 7 + * 2 -";
    number = -8.0f;
  }
  
  @Test //1st test
  void testIsInteger() {
    assertTrue(calc.isInteger("2"));
    assertFalse(calc.isInteger(" "));
    assertFalse(calc.isInteger("h") && calc.isInteger("["));
  }
  
  @Test //2nd test
  public void testEvaluateThrows() throws EmptyStackException, BadTypeException {
    assertThrows(InvalidExpression.class, () -> calc.evaluate(expr2));
    assertThrows(InvalidExpression.class, () -> calc.evaluate(expr3),
        "You cannot evaluate an empty expression!");
  }
  
  @Test //3rd test
  public void testEvaluate() 
      throws InvalidExpression, EmptyStackException, BadTypeException {
    assertEquals(number, calc.evaluate(expr1));
    assertTrue(calc.evaluate(expr4) == 63.0f);
  }
}
