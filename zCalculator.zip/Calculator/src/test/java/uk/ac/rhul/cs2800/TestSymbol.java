package uk.ac.rhul.cs2800;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

class TestSymbol {

  @Test ////First Test
  public void testSymbolConstructor() {
    Symbol times = Symbol.TIMES;
    assertEquals("*", times.getSymbol(), 
        "Test the Symbol Enum Constructor initialises Symbol Objects with specified symbol.");
  }
  
  @Test //Second Test
  public void testGetSymbol() {
    Symbol plus = Symbol.PLUS;
    Symbol times = Symbol.TIMES;
    assertFalse(plus.getSymbol() == times.getSymbol(), 
        "Test that calling getSymbol on a Symbol Object returns its symbol.");
  }
  
  @Test //Third Test
  public void testSymbolNotNull() {
    assertTrue((Symbol.valueOf("PLUS") != null), 
        "Test the Symbol Enum constant of the specified enumtype with specified name isn't null.");
  }
  
  @Test //Fourth Test
  public void isSymbol() {
    assertTrue(Symbol.PLUS.isSymbol(), 
        "Test that isSymbol method returns true if the calling Symbol exists in the Enum class.");
  }
  
  @Test //Fifth Test
  public void testIsSymbolNull() {
    Symbol plus = null;
    assertThrows(NullPointerException.class, () -> plus.isSymbol(), 
        "Calling isSymbol on a null object is not possible!");
  }
  
  @Test //Sixth Test
  void testCheckPrecedence() {
    assertEquals(Symbol.checkPrecedence("+"), 1,
        "Test that checkPrecedence method returns the correct precedence level for the symbol plus.");
    assertEquals(Symbol.checkPrecedence("("), 5,
        "Test that checkPrecedence method returns the correct precedence level for the symbol left bracket");
  }
}
