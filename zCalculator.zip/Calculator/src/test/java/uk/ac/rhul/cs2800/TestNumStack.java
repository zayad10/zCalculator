package uk.ac.rhul.cs2800;


import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.EmptyStackException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class TestNumStack {
  private NumStack numStack;
  private Float numValue;

  @BeforeEach 
  public void createNumStack() {
    numStack = new NumStack();
    numValue = 4.2f;
  }
  
  @Test //1st test
  public void testGetSize() {
    assertTrue(numStack.getSize() == 0);
  }

  @Test //2nd test
  public void testIsEmpty() {
    assertEquals(numStack.isEmpty(), true);
  }
  
  @Test //3rd test
  public void testPush() {
    numStack.push(numValue);
    assertFalse(numStack.isEmpty());
    assertTrue(numStack.getSize() == 1);
  }
  
  @Test //4th test
  public void testPop() throws BadTypeException {
    numStack.push(numValue);
    assertTrue(numStack.getSize() == 1);
    assertEquals(numValue, numStack.pop());
    assertTrue(numStack.isEmpty());
  }
  
  @Test //5th test
  public void popEmpty() throws EmptyStackException {
    assertThrows(EmptyStackException.class, () -> numStack.pop());;
  }
}
