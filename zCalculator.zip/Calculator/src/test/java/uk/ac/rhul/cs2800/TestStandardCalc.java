package uk.ac.rhul.cs2800;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.EmptyStackException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class TestStandardCalc {
  private StandardCalc calc;
  private String expr1;
  private String expr3;
  private String exprInvalid;
  private float expectedAnswer1;
  private float expectedAnswer2;
  
  @BeforeEach
  void createStandardCalc() {
    calc = new StandardCalc();
    expr1 = "1 * 2 + 3 * 4";
    expr3 = "( 33  * ( 1 + 3 ) ) - 22";
    expectedAnswer1 = 20.0f;
    expectedAnswer2 = 110.0f;
  }
  
  @Test //1st test
  void testIsInteger() {
    assertTrue(calc.isInteger("2"));
    assertFalse(calc.isInteger(" "));
    assertFalse(calc.isInteger("h") && calc.isInteger("["));
  }
  
  @Test //2nd test
  void testEvaluateThrows() {
    exprInvalid = "2 2";
    assertThrows(InvalidExpression.class, () -> calc.evaluate(exprInvalid),
        "You cannot evalaute Postfix Expressions!");
    exprInvalid = "2 2 2 2";
    assertThrows(InvalidExpression.class, () -> calc.evaluate(exprInvalid),
        "You cannot evaluate PostFix Expressions!");
  }
  
  @Test //3rd test
  void testReverseStringArray() {
    String[] test = {"1", "2", "3", "4", "5"};
    String output = StandardCalc.reverseStringArray(test, test.length);
    String expectedAnswer = "5 4 3 2 1 ";
    assertEquals(output, expectedAnswer,
        "Test that the method ReverseStringArray reverses the order of a String array"
        + "and returns it as a string.");
  }
  
  @Test //4th test
  void testEvaluate() throws EmptyStackException, InvalidExpression, BadTypeException {
    assertEquals(expectedAnswer1, calc.evaluate(expr1));
    assertTrue(calc.evaluate(expr3) == expectedAnswer2);
  }
}
