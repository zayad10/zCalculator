package uk.ac.rhul.cs2800;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.EmptyStackException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class TestStrStack {
  private StrStack strStack;
  private String stringValue;

  @BeforeEach 
  public void createStrStack() {
    strStack = new StrStack();
    stringValue = "TestString";
  }
  
  @Test //1st test
  public void testGetSize() {
    assertTrue(strStack.getSize() == 0);
  }
  
  @Test //2nd test
  public void testStrStackIsEmpty() {
    assertTrue(strStack.isEmpty(),
        "Test that String Stack is Empty upon construction");
  }
  
  @Test //3rd test
  public void testPush() {
    strStack.push(stringValue);
    assertTrue(strStack.isEmpty() == false,
        "Test that pushing a string Entry onto StrStack results in it being non empty");
  }
  
  @Test //4th test
  public void testPop() throws BadTypeException {
    strStack.push(stringValue);
    assertTrue(strStack.getSize() == 1);
    assertEquals(stringValue, strStack.pop());
    assertTrue(strStack.isEmpty());
  }
  
  //  @Test
  //  public void testPopException1() throws BadTypeException {
  //    strStack.push(null);
  //    assertThrows(BadTypeException.class, () -> strStack.pop());
  //  }
  
  @Test //5th test
  public void testPopException() throws EmptyStackException {
    assertThrows(EmptyStackException.class, () -> strStack.pop());
  }
  
  @Test //6th test
  public void popEmpty() throws EmptyStackException {
    assertThrows(EmptyStackException.class, () -> strStack.pop());;
  }
}