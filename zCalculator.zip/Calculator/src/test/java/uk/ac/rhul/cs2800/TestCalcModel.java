package uk.ac.rhul.cs2800;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.util.EmptyStackException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class TestCalcModel {
  private CalcModel calculator;
  private String badRvpExpression;
  private String rvpExpression;
  private String sdExpression;
  private String rvpExpression2;
  private String sdExpression2;

  @BeforeEach
  void createCalculator() {
    calculator = new CalcModel();
    rvpExpression = "1 2 3 + - 2 *";
    sdExpression = "1 * 2 + 3 * 4";
    badRvpExpression = sdExpression;
    rvpExpression2 = "3 1 2 + *";
    sdExpression2 = "( 1 + 2 * 3 - 4 ) / ( 2 * 2 )";
  }
  
  @Test //1st Test
  void testEvaluateThrows() throws EmptyStackException,
        InvalidExpression, BadTypeException {
    assertThrows(InvalidExpression.class,
        () -> calculator.evaluate(badRvpExpression, false));
  }
  
  @Test //2nd Test
  void testEvaluate() throws EmptyStackException,
        InvalidExpression, BadTypeException {
    assertEquals(calculator.evaluate(sdExpression, true), 20.0f);
    assertEquals(calculator.evaluate(rvpExpression, false), -8.0f);
    assertEquals(calculator.evaluate(rvpExpression2, false), 9.0f);
    assertEquals(calculator.evaluate(sdExpression2, true), -0.75f);
  }
  
}
