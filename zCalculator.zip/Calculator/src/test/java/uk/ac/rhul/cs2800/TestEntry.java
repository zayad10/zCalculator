package uk.ac.rhul.cs2800;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class TestEntry {
  private Entry tester;
  
  @BeforeEach
  public void setup() {
    tester = new Entry(5.2f);
  }
  
  @Test //First Test
  void testEntryFloatConstructor() throws BadTypeException {
    assertTrue(tester.getValue() == (5.2f), 
        "Test Float constructor initialises Entry Objects with float variable as its value field.");
  }
  
  @Test //Second Test
  void testEntrySymbolConstructor() throws BadTypeException {
    Entry e = new Entry(Symbol.PLUS);
    assertTrue(e.getSymbol() == Symbol.PLUS, 
        "Test Symbol constructor initialises Entry Object with a specified Symbol.");
  }
  
  @Test //Third Test
  void testEntryStringConstructor() throws BadTypeException {
    Entry e = new Entry("3");
    assertTrue(e.getString() == "3", 
        "Test that String constructor initialises Entry Objects with a specified String variable.");
  }
  
  @Test //Fourth Test
  void testInvalidEntryConstructor() throws BadTypeException {
    Entry e = new Entry();
    assertTrue(e.getType() == Type.INVALID,
        "Test that Invalid Entry constructor initialises empty Entry Object with INVALID type.");
  }
  
  @Test //Fifth Test
  void testEqualsMethod() {
    Entry e1 = new Entry("3");
    Entry e2 = new Entry("3");
    Entry e3 = new Entry("4");
    assertFalse(e1.equals(e3),
        "Test that two Entry objects with different String values are not equal");
    assertTrue(e1.equals(e2),
        "Test that two Entry objects with the same String values are equal");
  }
  
  @Test //Sixth Test
  void testHashcodeMethod() {
    Entry e1 = new Entry(5.2f);
    Entry e2 = new Entry(2.3f);
    assertEquals(tester.hashCode(), e1.hashCode(),
        "Test that the hashCode is the same for two Entries that have the same value");
    assertNotEquals(e1.hashCode(), e2.hashCode(),
        "Test that the hashCode for two entries with different values is not the same.");
  }
  
  @Test //Seventh Test
  void testGetValue() throws BadTypeException {
    Entry e1 = new Entry(6.4f);
    Entry e2 = new Entry(6.4f);
    assertEquals(e1.getValue(), e2.getValue(), 
        "Test that getValue method returns the calling Entry Object's value.");
  }
  
  @Test //Eighth Test
  void testGetSymbol() throws BadTypeException {
    Entry e = new Entry(Symbol.PLUS);
    assertEquals(e.getSymbol(), Symbol.PLUS, 
        "Test that getSymbol method returns the calling Entry Object's Symbol.");
  }
  
  @Test //Ninth Test
  void testGetNullSymbol()  {
    Entry e = new Entry(6.4f);
    assertThrows(BadTypeException.class, () -> e.getSymbol(), 
        "Cannot call getSymbol on an Entry with no Symbol!");
  }
  
  @Test //Tenth Test
  void testGetNullValue() {
    Entry e = new Entry("3");
    assertThrows(BadTypeException.class, () -> e.getValue(), 
        "Cannot call getValue on an Entry with no value!");
  }
  
  @Test //Eleventh Test
  void testGetNullString() {
    Entry e = new Entry(2.2f);
    assertThrows(BadTypeException.class, () -> e.getString(), 
        "Cannot call getString on an Entry with no String!");
  }
  
  @Test //Twelfth Test
  void testGetType() throws BadTypeException {
    Entry e = new Entry(4.2f);
    assertEquals(e.getType(), Type.NUMBER, 
        "Test that getType method returns the calling Entry Object's type.");
  }
  
  @Test //Thirteenth Test
  void testToString() {
    Entry e = new Entry(4.2f);
    String entryE = "4.2";
    assertEquals(e.toString(), entryE,
        "Test that toString method returns the correct String.");
  }
}
