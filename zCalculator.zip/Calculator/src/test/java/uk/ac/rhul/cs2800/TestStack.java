package uk.ac.rhul.cs2800;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.EmptyStackException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class TestStack {
  private Stack entryStack;

  @BeforeEach 
  public void createStack() {
    entryStack = new Stack();
  }
  
  @Test //First Test
  public void testCreateStack() {
    assertTrue(entryStack != null, 
        "Test a newly created stack to see if it has been initialized,");
  }
  
  @Test //Second Test
  public void testPush() throws BadTypeException {
    entryStack.push(new Entry(5.0f));
    Entry gotten = entryStack.pop();
    assertEquals(5, gotten.getValue(), 
        "Test that pushing an entry adds it onto the stack.");
  }
  
  @Test //Third Test
  public void testSize() throws BadTypeException {
    entryStack.push(new Entry(2.2f));
    entryStack.push(new Entry(5.4f));
    assertEquals(2, entryStack.getSize(), 
        "Test a newly created stack for size two after pushing twice.");
  }
  
  @Test //Fourth Test
  public void testPushTwice() {
    entryStack.push(new Entry(2.2f));
    entryStack.push(new Entry(3.4f));
    assertTrue(entryStack.getSize() == 2, 
        "Test that pushing twice on an empty stack gives a stack with size 2.");
  }
  
  @Test //Fifth Test
  void pushLots() {
    Entry e = new Entry(5.2f);
    for (int index = 0; index < 1000; index++) {
      entryStack.push(e);
    }
    assertTrue(entryStack.getSize() == 1000, 
        "Pushing 1000 entries on an empty stack should increase the size by 1000.");
  }
  
  @Test //Sixth Test
  public void testEmpty() {
    assertTrue(entryStack.isEmpty(), 
        "Test a newly created stack to see that it is empty.");
  }
  
  @Test //Seventh Test
  public void testPop() throws BadTypeException {
    entryStack.push(new Entry(34f));
    assertTrue(entryStack.pop().getValue() == 34f, 
        "Pushing then popping should return value equal to the value pushed.");
    assertTrue(entryStack.isEmpty(), 
        "Pushing, then popping should give an empty stack.");
  }
  
  
  @Test //Eighth Test
  public void testPopTwice() throws BadTypeException {
    entryStack.push(new Entry("3"));
    entryStack.push(new Entry(Symbol.DIVIDE));
    assertEquals(entryStack.pop().getSymbol(), Symbol.DIVIDE, 
        "Pushing twice then popping should return the element at top.");
    assertEquals(entryStack.pop().getString(), "3", 
        "Pushing twice then popping twice should return the first element pushed.");
    assertTrue(entryStack.isEmpty(), 
        "Pushing twice, then popping twice should give an empty stack");
    assertThrows(EmptyStackException.class, () -> entryStack.pop(), 
        "Popping from empty stack is not Possible!");
  }
  
  @Test //Ninth Test
  public void testPopPush() throws BadTypeException {
    entryStack.push(new Entry(4f));
    Entry gotten = entryStack.pop();
    assertEquals(4f, gotten.getValue(), 
        "Test that if an Entry is pushed then popped it will return the value pushed.");
  }
  
  @Test //Tenth Test
  public void testPopThenIsEmpty() throws BadTypeException {
    entryStack.push(new Entry(2.2f));
    assertEquals(entryStack.pop().getValue(), 2.2f, 
        "Pushing 2.2 and then popping should equal 2.2");
    assertThrows(EmptyStackException.class, () -> entryStack.pop(), 
        "Popping from an Empty Stack is not possible!");
  }
  
  @Test //Eleventh Test
  public void testEmptyPop() {
    assertThrows(EmptyStackException.class, () -> entryStack.pop(), 
        "Popping from an empty stack is not possible!");
  }
  
  
  @Test //Twelfth Test
  public void testEmptyTop() {
    assertThrows(EmptyStackException.class, () -> entryStack.top(), 
        "Executing Top on an empty stack is not possible!");
  }
  
  @Test //Thirteenth Test
  public void testFloatTopEntry() throws BadTypeException {
    entryStack.push(new Entry(2.4f));
    entryStack.push(new Entry(3.4f));
    entryStack.push(new Entry(4.4f));
    assertEquals(entryStack.top().getValue(), entryStack.pop().getValue(), 
        "Pushing 3 entries then popping should return the current top element");
    assertEquals(3.4f, entryStack.top().getValue(), 
        "Pushing 3 times, popping, then executing top should return second entry pushed");
  }
  
  @Test //Fourteenth Test
  public void testStringTopEntry() throws BadTypeException {
    entryStack.push(new Entry("3"));
    entryStack.push(new Entry("4"));
    assertTrue(entryStack.getSize() == 2, 
        "Pushing twice should give a stack of size 2.");
    entryStack.pop();
    assertFalse(entryStack.getSize() == 2, 
        "Popping should decrement the size of the stack by 1.");
    assertEquals("3", entryStack.top().getString(), 
        "Pushing twice, popping once, then executing top should return the first entry pushed");
  }
  
  @Test //Fifteenth Test
  public void testSymbolTopEntry() throws BadTypeException {
    entryStack.push(new Entry(Symbol.PLUS));
    entryStack.push(new Entry(Symbol.DIVIDE));
    entryStack.pop();
    assertEquals(Symbol.PLUS, entryStack.top().getSymbol(), 
        "Test pushing twice, popping once, then executing top returns the first Entry pushed.");
  }
}
