package uk.ac.rhul.cs2800;

import java.util.EmptyStackException;

/** This Class represents a stack of Operator arguments.
 * It uses calls of the Stack class' methods to implement new edited methods.
 * @author ZAYAD KHAN
 *
 */
public class OpStack {

  /**
   * The stack of Symbol entries.
   */
  private Stack opStack = new Stack();
  
  /** Gets the size of the OpStack.
   * @return int the size of the OpStack.
   */
  public int getSize() {
    return opStack.getSize();
  }
  
  /** Check the Stack has no entries.
   * @return boolean true if empty.
   */
  public boolean isEmpty() {
    return opStack.getSize() == 0;
  }
  
  /** Push an entry onto the stack.
   * @param operator the Symbol.
   */
  public void push(Symbol operator) {
    Entry e = new Entry(operator);
    opStack.push(e);
  }
  
  /** Pop the top entry off the stack and decrement the stacks size.
   * @return Symbol the top entry.
   * @throws EmptyStackException if opStack empty
   * @throws BadTypeException if the top entry not of type String.
   */
  public Symbol pop() throws EmptyStackException, BadTypeException {
    if (isEmpty()) {
      throw new EmptyStackException();
    }
    if (opStack.top().getType() != Type.SYMBOL) {
      throw new BadTypeException();
    }
    return opStack.pop().getSymbol();
  }
  
  /** Get the top element out of the stack and return it.
   * @return Symbol the top element
   * @throws EmptyStackException if opStack is empty.
   * @throws BadTypeException if opStack top element not of type Symbol.
   */
  public Symbol top() throws EmptyStackException, BadTypeException {
    if (isEmpty()) {
      throw new EmptyStackException();
    }
    return opStack.top().getSymbol();
  }
}