package uk.ac.rhul.cs2800;

import java.util.EmptyStackException;

/**This class represents a stack of only string arguments.
 * It calls methods of stack class to implement new edited methods.
 * @author ZAYAD KHAN
 *
 */
public class StrStack {

  /**
   * The stack of String entries.
   */
  private Stack strStack = new Stack();
  
  /** Get the size of the StrStack.
   * @return int size of the StrStack.
   */
  public int getSize() {
    return strStack.getSize();
  }
  
  /** Check StrStack has no entries.
   * @return boolean true if empty 
   */
  public boolean isEmpty() {
    return (strStack.getSize() == 0);
  }
  
  /** Push an entry onto the stack.
   * @param s the String.
   */
  public void push(String s) {
    Entry e = new Entry(s);
    strStack.push(e);
  }
  
  /** Pop the top entry off the stack and decrement the stacks size.
   * @return String the top entry.
   * @throws EmptyStackException if StrStack empty
   * @throws BadTypeException if the top entry not of type String.
   */
  public String pop() throws EmptyStackException, BadTypeException {
    if (isEmpty()) { //checks if the StrStack is empty
      throw new EmptyStackException();
    }
    if (strStack.top().getType() != Type.STRING) { //checks if the top element is not of type String
      throw new BadTypeException();
    }
    return strStack.pop().getString(); //otherwise return the String of the popped entry.
  }
}
