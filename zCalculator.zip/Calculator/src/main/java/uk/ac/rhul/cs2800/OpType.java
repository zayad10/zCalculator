package uk.ac.rhul.cs2800;

/**
 * This enum class represents the different types of expressions.
 * @author OWNER
 *
 */
public enum OpType {
  /**
   * Standard Order with operator between arguments.
   */
  INFIX,
  /**
   * Reverse Polish Notation such as "325+*".
   */
  POSTFIX
}
