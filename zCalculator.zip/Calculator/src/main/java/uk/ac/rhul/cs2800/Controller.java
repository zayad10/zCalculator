package uk.ac.rhul.cs2800;

import java.util.EmptyStackException;

/** 
 * This class represents the controller that will add itself as an observer
 * to the View so that changes can be observed.
 * @author Zayad Khan
 *
 */
public class Controller {
  /**
   * The View to be observed.
   */
  public ViewInterface view;
  
  /**
   * The combined calculator that evaluates expressions.
   */
  CalcModel calc = new CalcModel();
  
  /**
   * The value that defines if the expression is infix or not.
   */
  boolean infix = true;

  /**
   * An intermediate variable that is used in the calculation of expressions.
   */
  float ans;
  
  /**
   * The expression to be evaluated.
   */
  String userExpression;
  
  /**
   * Reset the answer field.
   */
  public void handleReset() {
    view.setAnswer(null);
  }
  
  /**
   * Calculate the answer to the expression entered by the user.
   */
  public void handleCalc() {
    userExpression = view.getUserExpression();
    try {
      if (userExpression.isEmpty()) {
        throw new EmptyStackException();
      }
      if (userExpression.matches(".*[a-zA-Z]+.*")) {
        throw new InvalidExpression();
      }
      
      if (userExpression.contains("/ 0")) {
        throw new InvalidExpression();
      }
      if ((userExpression.length() == 1) || (userExpression.length() == 2)) {
        throw new InvalidExpression();
      } else {
        ans = calc.evaluate(view.getUserExpression(), infix);
      }
    } catch (EmptyStackException e) {
      view.setAnswer("Please do not enter an empty expression!");
      return;
    } catch (InvalidExpression e) {
      view.setAnswer("Invalid Expression!");
      return;
    } catch (BadTypeException e) {
      view.setAnswer("Bad Type!");
      return;
    }
    view.setAnswer("" + ans);
  }
  
  /**
   * Change the calculation type depending on the mode selected by user.
   * @param type the expression type.
   */
  private void handleType(OpType type) {
    view.setType("" + type);
    if (type.toString() == "POSTFIX") {
      infix = false;
    }
    if (type.toString() == "INFIX") {
      infix = true;
    }
  }

  /**
   * Create a view.
   * @param view the View GUI or ASCII.
   */
  public Controller(ViewInterface view) {
    this.view = view;
    view.addResetObserver(this::handleReset);
    view.addCalcObserver(this::handleCalc);
    view.addTypeObserver(this::handleType);
  }
}
