package uk.ac.rhul.cs2800;

import java.util.EmptyStackException;

/**
 * This class represents a Calculator that evaluates infix expressions.
 * The Standard Calc accepts Infix Expressions and converts it to postfix
 * and then uses RevPolishCalc's evaluate method evaluate it.
 * Used pseudo code algorithm from https://brilliant.org/wiki/shunting-yard-algorithm/
 * Author of algorithm Beakal Tiliksew, Josh Thelwall, Jimin Khim
 * 
 * @author Zayad Khan
 */
public class StandardCalc implements Calculator {
  /**
   * The Reverse Polish Notation Calculator.
   */
  private RevPolishCalc rpCalc;
  /**
   * The stack of operators.
   */
  private OpStack operators;
  /**
   * The output queue to be processed.
   */
  private StrStack outputQueue;
  
  /** Check that the expression is an integer.
   * @param expr the expression String.
   * @return true, if expression is an integer
   */
  public boolean isInteger(String expr) {
    try {
      Integer.parseInt(expr);
      return true;
    } catch (NumberFormatException e) {
      return false;
    }
  }
  
  /** Reverse a String Array and return it as a String.
   * @param input the String Array
   * @param arrayLength the length of the String Array to be reversed.
   * @return String the input String array as a String.
   */
  public static String reverseStringArray(String[] input, int arrayLength) {
    String[] arrayReformed = new String[arrayLength];
    StringBuilder tempArray = new StringBuilder();
    int i = 0;
    int j;
    for (j = arrayLength - 1; j >= 0; j--) { 
      //for loop used here as we need to iterate through the entire
      //input string.
      arrayReformed[i] = input[j];
      i++;
    }
    for (String s : arrayReformed) {
      tempArray.append(s).append(" ");
    }
    String outputString = tempArray.toString();
    return outputString;
  }
  
  //Used pseudo code algorithm from https://brilliant.org/wiki/shunting-yard-algorithm/
  //Author of algorithm Beakal Tiliksew, Josh Thelwall, Jimin Khim
  /**
   * Evaluate an Infix expression.
   *
   * @param expr the expression String.
   * @return float the answer.
   * @throws InvalidExpression if an Invalid Expression is entered.
   * @throws BadType if a non String expression is entered.
   * @throws EmptyStackException If there are no elements in the expression.
   */
  @Override
  public float evaluate(String expr)
      throws InvalidExpression, BadTypeException, EmptyStackException {
    if (expr.isBlank() || expr.isEmpty()) {
      throw new InvalidExpression(); //if Expression empty then throw an exception
    }
    rpCalc = new RevPolishCalc();
    operators = new OpStack();
    outputQueue = new StrStack();
    
    String[] exprArray = expr.split("\\s+");
    StringBuilder rpnExpr = new StringBuilder(); //New RPN string after transformation
    
    if (isInteger(exprArray[0]) && isInteger(exprArray[1])) {
      throw new InvalidExpression(); 
      //An expression with the first 2 characters being numbers is a postfix expression
    }
    
    for (String token : exprArray) { //for loop over the entire array expression  
      if (isInteger(token)) {
        outputQueue.push(token + " ");
      }
      
      /**  if (operators.isEmpty()) { 
       //this nested if loop just adds the first symbol when opStack is empty
          if (!isInteger(token)) {
            if (token.equals(Symbol.TIMES.getSymbol())) {
              operators.push(Symbol.TIMES);
            }
            if (token.equals(Symbol.DIVIDE.getSymbol())) {
              operators.push(Symbol.DIVIDE);
            }
            if (token.equals(Symbol.PLUS.getSymbol())) {
              operators.push(Symbol.PLUS);
            }
            if (token.equals(Symbol.MINUS.getSymbol())) {
              operators.push(Symbol.MINUS);
            }
            if (token.equals(Symbol.LEFT_BRACKET.getSymbol())) {
              operators.push(Symbol.LEFT_BRACKET);
            }
           // if (token.equals(Symbol.RIGHT_BRACKET.getSymbol())) 
           // * { //if the first element of the expression is closing bracket its invalid
           //   throw new InvalidExpression();
           // }
          } */
      //} 
      if (!isInteger(token) && !(token.equals(Symbol.LEFT_BRACKET.getSymbol())) 
          && !(token.equals(Symbol.RIGHT_BRACKET.getSymbol()))) {
        while (!operators.isEmpty() 
               && (operators.top().precedence < Symbol.checkPrecedence(token))) {
          outputQueue.push(operators.pop().getSymbol() + " ");
          //if the token is not a number, not a left bracket, not a right bracket,
          // whilst the opStack is not empty 
          //and the operator at top of stack precedence level is less than the 
          //current token precedence
          //pop the operator and add it to the outputQueue
        }
        if (token.equals(Symbol.TIMES.getSymbol())) {
          operators.push(Symbol.TIMES);
        }
        if (token.equals(Symbol.DIVIDE.getSymbol())) {
          operators.push(Symbol.DIVIDE);
        }
        if (token.equals(Symbol.PLUS.getSymbol())) {
          operators.push(Symbol.PLUS);
        }
        if (token.equals(Symbol.MINUS.getSymbol())) {
          operators.push(Symbol.MINUS);
        }
      } else if (token.equals(Symbol.LEFT_BRACKET.getSymbol())) {
        operators.push(Symbol.LEFT_BRACKET);
           
      } else if (token.equals(Symbol.RIGHT_BRACKET.getSymbol())) {
        while (!(operators.top().equals(Symbol.LEFT_BRACKET))) {
          outputQueue.push(operators.pop().getSymbol() + " ");
        }
        operators.pop();
      } 
    }
    while (!(operators.isEmpty())) {
      outputQueue.push(operators.pop().getSymbol() + " ");
    }
    while (!(outputQueue.isEmpty())) {
      rpnExpr.append(outputQueue.pop());
    }
    rpnExpr.deleteCharAt(rpnExpr.length() - 1);
    String rpnExprString = rpnExpr.toString();
    String[] toStringOutput = rpnExprString.split("\\s+");
    String rpnExpression = reverseStringArray(toStringOutput, toStringOutput.length);
    return rpCalc.evaluate(rpnExpression);
  }
}
