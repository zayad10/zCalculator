package uk.ac.rhul.cs2800;

import java.util.ArrayList;
import java.util.EmptyStackException;

/** This class represents a stack of entries.
 * 
 * @author ZAYAD
 */
public class Stack {
  /**
   * Size of the stack.
   */
  private int size = 0;
  /**
   * List of entries.
   */
  public ArrayList<Entry> entries; //ArrayList chosen as data structure as it does not have the limiting index like Array does.
  
  /**
   * Create an empty list of entries.
   */
  public Stack() {
    entries = new ArrayList<Entry>(); //Stack constructor creates an empty array list of Entry Object Type. ArrayList chosen so that we dont have limit to adding entries like an array does.
  }
  
  /**
   * Get number of elements in stack.
   * 
   * @return the size of the stack.
   */
  public int getSize() {
    return size;
  }
  
  /**
   * Add an element to the top of the stack.
   * 
   *@param e the next entry to push.
   */
  public void push(Entry e) {
    entries.add(e);
    size++;
  }
  
  /**
   * Get the top element out of the stack and return it.
   * @return top element.
   */
  public Entry top() {
    if (isEmpty()) {
      throw new EmptyStackException();
    }
    return entries.get(getSize() - 1);
  }

  /**
   * Get the top element out of the stack (remove it) and return it.
   * 
   * @return top element.
   */
  public Entry pop() {
    if (isEmpty()) {
      throw new EmptyStackException();
    } else {
      return entries.remove(--size);
    }
  }
  
  /**
   * Check stack has no elements.
   * @return true if stack has no elements.
   */
  public boolean isEmpty() {
    return (size == 0);
  }
}
