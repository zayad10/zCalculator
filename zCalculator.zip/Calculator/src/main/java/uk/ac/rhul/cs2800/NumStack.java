package uk.ac.rhul.cs2800;

import java.util.EmptyStackException;

/** This class represents a stack of Float(Number) entries.
 * @author ZAYAD KHAN
 *
 */
public class NumStack {
  /**
   * The stack consisting of only Float entries.
   */
  private Stack numStack = new Stack();
  
  
  /** Gets the size of the NumStack.
   * @return int the size of the numStack.
   */
  public int getSize() {
    return numStack.getSize();
  }
  
  /** Check the Stack has no entries.
   * @return boolean true if stack is empty.
   */
  public boolean isEmpty() {
    return (numStack.getSize() == 0);
  }
  
  /** Push an entry onto the stack.
   * @param n the Float to push.
   */
  public void push(Float n) {
    Entry e = new Entry(n);
    numStack.push(e);
  }
  
  /** Pop the top element off the stack and decrement the stacks size.
   * @return Float the top entry.
   * @throws EmptyStackException if stack is empty.
   * @throws BadTypeException if the top element is not of type Float.
   */
  public Float pop() throws EmptyStackException, BadTypeException {
    if (isEmpty()) {
      throw new EmptyStackException();
    }
    if (numStack.top().getType() != Type.NUMBER) {
      throw new BadTypeException();
    }
    return numStack.pop().getValue();
  }
}
