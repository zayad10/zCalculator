package uk.ac.rhul.cs2800;

/** 
 * This enum is a wrapper to hide the type of the contained value.
 * 
 * @author ZAYAD
 *
 */
public enum Symbol {
  LEFT_BRACKET("(", 5), RIGHT_BRACKET(")", 6), TIMES("*", 3),
  DIVIDE("/", 4), PLUS("+", 1), MINUS("-", 2), INVALID("N/A", 0);
  /**
   * A symbol value to be stored inside the enum.
   */
  private String symbol;
  /**
   * Precedence is used in the Shunting algorithm when implementing the Standard Calculator. 
   */
  public int precedence;


  /**
   * Create a symbol with a specified value.
   * 
   * @param symbol the symbol of choice.
   */
  private Symbol(String symbol, int precedence) {
    this.symbol = symbol;
    this.precedence = precedence;
  }
  
  /** Print the symbol to a string. */
  @Override
  public String toString() {
    return symbol;
  }
  
  /** 
   * @return a string representing the symbol. 
   */
  public String getSymbol() {
    return symbol;
  }
  
  /**Check precedence of Symbol.
   * @param symbol the symbol to be checked.
   * @return precedence int.
   */
  public static int checkPrecedence(String symbol) {
    if (symbol.equals(Symbol.LEFT_BRACKET.getSymbol())) {
      return LEFT_BRACKET.precedence;
    }
    if (symbol.equals(Symbol.RIGHT_BRACKET.getSymbol())) {
      return RIGHT_BRACKET.precedence;
    }
    if (symbol.equals(Symbol.DIVIDE.getSymbol())) {
      return DIVIDE.precedence;
    }
    if (symbol.equals(Symbol.MINUS.getSymbol())) {
      return MINUS.precedence;
    }
    if (symbol.equals(Symbol.TIMES.getSymbol())) {
      return TIMES.precedence;
    }
    if (symbol.equals(Symbol.PLUS.getSymbol())) {
      return PLUS.precedence;
    }
    if (symbol.equals(Symbol.INVALID.getSymbol())) {
      return INVALID.precedence;
    }
    else {
      return 0;
    }
  }
  
  /** 
   * Check if this is a symbol.
   * 
   * @return true if this is a symbol.
   */
  public boolean isSymbol() {
    Symbol[] allSymbols = Symbol.values();
    for (Symbol asymbol : allSymbols) {
      if (asymbol.symbol.equals(this.getSymbol())) {
        return true; 
      }
    }
    return false;
  }
}
