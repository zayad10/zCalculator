package uk.ac.rhul.cs2800;


/**
 * This class is a wrapper to hide the type of the contained value.
 * @author ZAYAD
 */
public class Entry {
  /**
   * A string value inside the entry.
   */
  private String str;
  /**
   * A type value inside the entry.
   */
  private Type type;
  /**
   * A symbol value inside the entry.
   */
  private Symbol symbol;
  //= Symbol.INVALID;
  /**
   * A float value inside the entry.
   */
  private Float number;
  
  /** 
   * Create an entry with a specified value.
   * 
   * @param v the value of the entry.
   */
  public Entry(float v) { //value here is float.
    number = v;
    this.type = Type.NUMBER;
  }
  
  /** 
   * Create an entry with a specified symbol.
   * 
   * @param which the entries symbol.
   */
  public Entry(Symbol which) {
    symbol = which;
    this.type = Type.SYMBOL;
  }
  
  /** 
   * Create an entry with a specified string.
   * 
   * @param str the entries string.
   */
  public Entry(String str) {
    this.str = str;
    this.type = Type.STRING;
  }
  
 // /** Create an entry with a specified type.
 //  * 
 //  * @param type the entries type.
 //  */
 // public Entry(Type type) {
//    this.type = type;
 // }
  
  
  /** Create an Invalid Entry object. 
   * 
   */
  public Entry() {
    this.type = Type.INVALID;
  }
  
  /**
   * Generate a custom hashCode to differentiate Entry Objects via an integer value.
   */
  @Override
  public int hashCode() {
    final int prime = 31;
    int result = 1;
    result = prime * result + ((symbol == null) ? 0 : symbol.hashCode());
    result = prime * result + ((str == null) ? 0 : str.hashCode());
    result = prime * result + ((type == null) ? 0 : type.hashCode());
    result = prime * result + ((number == null) ? 0 : number.hashCode());
    return result;
  }

  /**
   * Generate a custom Equals method to check if two entry objects are the same
   * based on the object in the paramater contents being the exact same.
   */
  @Override
  public boolean equals(Object obj) {
    if (this == obj) {
      return true;
    }
    if (!(obj instanceof Entry)) {
      return false;
    }
    Entry symbol = (Entry) obj;
    if (this.symbol != symbol.symbol) {
      return false;
    }
    if (str == null) {
      if (symbol.str != null) {
        return false;
      }
    } else if (!str.equals(symbol.str)) {
      return false;
    }
    if (type != symbol.type) {
      return false;
    }
    if (number == null) {
      if (symbol.number != null) {
        return false;
      }
    } else if (!number.equals(symbol.number)) {
      return false;
    }
    return true;
  }
  
  /** 
   * Get the contents of the entry.
   * 
   * @return the symbol.
   * 
   * @throws BadTypeException thrown if Entry not of type Symbol.
   */
  public Symbol getSymbol() throws BadTypeException {
    if (type != Type.SYMBOL) {
      throw new BadTypeException();
    }
    return symbol;
  }
  
  /**
   * Get the contents of the entry.
   * 
   * @return the type.
   * 
   * @throws BadTypeException thrown when the type is Null.
   */
  public Type getType() throws BadTypeException {
    if (type == null) {
      throw new BadTypeException();
    }
    return type;
  }
  
  /** 
   * Get the contents of the entry.
   * 
   * @return the number.
   * 
   * @throws BadTypeException thrown when Entry not of type Number.
   */
  public float getValue() throws BadTypeException {
    if (type != Type.NUMBER) {
      throw new BadTypeException();
    }
    return number;
  }
  
  /** 
   * Get the contents of the entry.
   * 
   * @return the string.
   * 
   * @throws BadTypeException thrown when Entry not of type String.
   */
  public String getString() throws BadTypeException {
    if (type != Type.STRING) {
      throw new BadTypeException();
    }
    return str;
  }

  /**
   * Generate a custom toString method to print Entry Objects to a string.
   */
  @Override
  public String toString() {
    String s = null;

    try {
      if (this.getType().equals(Type.NUMBER)) {
        s = String.valueOf(this.number);
      }
    } catch (BadTypeException e) {
      e.printStackTrace();
    }

    try {
      if (this.getType().equals(Type.SYMBOL)) {
        s = this.symbol.getSymbol();
      }
    } catch (BadTypeException e) {
      e.printStackTrace();
    }

    try {
      if (this.getType().equals(Type.STRING)) {
        s = str;
      }
    } catch (BadTypeException e) {
      e.printStackTrace();
    }

    return s;
  }
}
