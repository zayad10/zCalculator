package uk.ac.rhul.cs2800;

import java.util.EmptyStackException;

/** The calculator interface which will be used in the CalcModel class.
 * This interface will help in the creation of a combined interface for a calculator.
 * @author OWNER
 *
 */
public interface Calculator {
  
  /** Evaluate an expression.
   * @param what the String expression to evaluate.
   * @return Float the answer.
   * @throws InvalidExpression If an invalid expression is passed.
   * @throws BadTypeException If a non string is passed.
   * @throws EmptyStackException If the expression is empty.
   */
  float evaluate(String what) throws InvalidExpression, BadTypeException, EmptyStackException;
}
