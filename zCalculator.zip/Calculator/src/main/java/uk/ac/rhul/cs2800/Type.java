package uk.ac.rhul.cs2800;

/** 
 * This enum is a wrapper to hide the type of the contained value.
 * 
 * @author ZAYAD
 *
 */
public enum Type {
  NUMBER("Number"), SYMBOL("Symbol"), STRING("String"), INVALID("INVALID");
  /**
   * A type value to be stored inside the enum.
   */
  private String type;

  /**
   * Create a type with a specified value.
   * @param type the type of choice.
   */
  private Type(String type) {
    this.type = type;
  }
      
  /** Print the type to a string. */
  @Override
  public String toString() {
    return type;
  }
  
  /** 
   * @return the type. 
   */
  public String getType() {
    return this.type;
  }
  
  /** 
   * Check if this is a type.
   * @return true if this is a type.
   */
  public boolean isType() {
    Type[] allTypes = Type.values();
    for (Type atype : allTypes) {
      if (atype.type.equals(this.getType())) {
        return true; 
      }
    }
    return false;
  }
}
