package uk.ac.rhul.cs2800;

/**
 * This interface defines a new functional type that we name Observer.
 * @author Zayad Khan
 *
 */
@FunctionalInterface
public interface Observer {
  /**
  * The mechanism that we will use when we are notifying an Observer.
  */
  public void notifyObservers();
}