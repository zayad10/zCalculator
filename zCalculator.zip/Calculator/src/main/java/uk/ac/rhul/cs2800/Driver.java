package uk.ac.rhul.cs2800;

/** 
 * The class starts up the calculator.
 * @author Zayad Khan
 *
 */
public class Driver {
  /**
   * The main method that sets up the view and controller.
   * @param args the view.
   */
  public static void main(String[] args) {  
    ViewInterface view = CalcView.getInstance();
    //view = new AsciiView();
    new Controller(view); 
  }
}
