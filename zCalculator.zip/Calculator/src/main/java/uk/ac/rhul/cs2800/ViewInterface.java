package uk.ac.rhul.cs2800;

import java.util.function.Consumer;

/**
 * This interface defines how we want to interact with out calculator.
 * It defines the data and provides hooks for notification
 * and insertion of observers.
 * 
 * @author Zayad Khan
 *
 */
public interface ViewInterface {

  /** Add an observer of the Type action.
   * @param type the expression type.
   */
  void addTypeObserver(Consumer<OpType> type);
  
  /** Add an observer of the reset answer action.
   * @param o the observer
   */
  void addResetObserver(Observer o);
  
  /** A hook to get the arithmetic expression to be evaluated.
   * @return String the expression to evaluate.
   */
  String getUserExpression(); //gets user expression
  
  /** A hook to show the user their evaluated answer.
   * @param answer the answer.
   */
  void setAnswer(String answer);
  
  /** Add an observer of the Calculate action.
   * @param o the observer
   */
  void addCalcObserver(Observer o);
  
  /** A hook to show the user the type they have selected.
   * @param type the expression type.
   */
  void setType(String type);
}