package uk.ac.rhul.cs2800;

import java.util.EmptyStackException;

/** This Class Represents a Calculator that evaluates RPN Expressions.
 * @author Zayad Khan
 *
 */
public class RevPolishCalc implements Calculator {
  /**
   * The NumStack which only only accepts Number entries.
   */
  private static NumStack stack = new NumStack();

  /** Check that an expression String is an integer.
   * @param expr the expression String.
   * @return true, if expression is an Integer.
   */
  public boolean isInteger(String expr) {
    try {
      Integer.parseInt(expr);
      return true;
    } catch (NumberFormatException e) {
      return false;
    }
  }
  
  /**
   * Evaluate a PostFix (RPN) expression.
   *
   * @param expr the expression String.
   * @return float the answer.
   * @throws InvalidExpression if an Invalid Expression is entered.
   * @throws BadType if a non String expression is entered.
   * @throws EmptyStackException If there are no elements in the expression.
   */
  @Override
  public final float evaluate(String expr)
      throws InvalidExpression, BadTypeException, EmptyStackException {
    
    String[] exprArr = expr.split("\\s+");
    if ((isInteger(exprArr[0]) && !isInteger(exprArr[1]))
        //|| (!isInteger(exprArr[0])) //check for only one expression
        || (exprArr.length < 2) //check if less than 2 values on the stack
        || (!isInteger(exprArr[0]) && !isInteger(exprArr[1])
        || (!isInteger(exprArr[0]) && isInteger(exprArr[1])))) {
      throw new InvalidExpression();
    }
    String operators = "+-/*";
    for (String expressionString: exprArr) {
      if (isInteger(expressionString) && !operators.contains(expressionString)) {
        stack.push(Float.valueOf(expressionString));
      } else {
        float firstExpression = stack.pop();
        float secondExpression = stack.pop();
        int operatorIndex = operators.indexOf(expressionString);
        switch (operatorIndex) {
          case 0:
            stack.push(firstExpression + secondExpression);
            break;
          case 1:
            stack.push(secondExpression - firstExpression);
            break;
          case 2:
            stack.push(secondExpression / firstExpression);
            break;
          case 3:
            stack.push(firstExpression * secondExpression);
            break;
          default:
            break;
        }
      }
    }
    return stack.pop();
  }
}
