package uk.ac.rhul.cs2800;

/**
 * This exception class handles bad type inputs.
 * @author ZAYAD
 *
 */
public class BadTypeException extends Exception {
  /**
   * Print error message.
   */
  public void badType() {
    System.err.println("Bad type!");
  }
}
