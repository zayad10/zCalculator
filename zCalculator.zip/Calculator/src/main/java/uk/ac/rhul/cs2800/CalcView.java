package uk.ac.rhul.cs2800;

import java.util.function.Consumer;
import javafx.application.Application;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.Toggle;
import javafx.scene.control.ToggleButton;
import javafx.scene.control.ToggleGroup;
import javafx.stage.Stage;

/** 
 * This is the JavaFX view of the Calculator. 
 * It is filled by the fxml loader at runtime.
 * @author OWNER
 *
 */
public class CalcView extends Application implements ViewInterface {
  private static double versionNumber = 0.72;
  
  /**
   * The expression to be resolved.
   */
  @FXML
  private TextField expressionText;

  /**
   * The on screen calculate button.
   */
  @FXML
  private Button calcButton;

  /**
   * The on screen reset button.
   */
  @FXML
  private Button resetButton;

  /**
   * The answer of the expression that is resolved.
   */
  @FXML
  private TextField answerText;

  /**
   * The on screen answer label.
   */
  @FXML
  private Label answerLbl;

  /**
   * The on screen infix mode button.
   */
  @FXML
  private ToggleButton infixBtn;

  /**
   * The object that links the two radio buttons.
   */
  @FXML
  private ToggleGroup typeOperation;

  /**
   * The on screen RPN mode button.
   */
  @FXML
  private ToggleButton rpnBtn;

  /**
   * The current calculation type mode.
   */
  @FXML
  private TextField currentMode;
  
  private static volatile CalcView instance = null;
      
  /**
   * Initialize a singleton instance.
   */
  @FXML
  void initialize() {
    instance = this; 
    // Make it a JavaFX singleton. Instance is set by the javafx "initialize" method
  }
      
  /** Get an Instance of the GuiView.
   * @return CalcView the Instance of the Graphical Calculator.
   */
  public static synchronized CalcView getInstance() {
    if (instance == null) {
      new Thread(() -> Application.launch(CalcView.class)).start();
      //wait until the instance is ready since initialization has started
      while (instance == null) {
      }
    }
    return instance;
  }
      
  /**
   * Start the Graphical Interface.
   */
  @Override
  public void start(Stage primaryStage) throws Exception {
    Parent root = FXMLLoader.load(CalcView.class.getClassLoader().getResource("View.fxml"));
    Scene scene = new Scene(root);
    scene.getStylesheets()
        .add(getClass().getClassLoader().getResource("application.css").toExternalForm());
    primaryStage.setScene(scene);
    primaryStage.setTitle("zCalculator Version " + versionNumber);
    primaryStage.show();
  }

  /** Add an observer of the Type action.
   * @param type the expression type.
   */
  @Override
  public void addTypeObserver(Consumer<OpType> type) {
    typeOperation.selectedToggleProperty().addListener(new ChangeListener<Toggle>() {
      @Override
      public void changed(ObservableValue<? extends Toggle> observable, Toggle from, Toggle to) {
        type.accept(to == infixBtn ? OpType.INFIX : OpType.POSTFIX);
      }
    });
  }

  /** Add an observer of the reset answer action.
   * @param o the observer
   */
  @Override
  public void addResetObserver(Observer o) {
    resetButton.setOnAction(event -> o.notifyObservers());
    
  }

  /** A hook to get the arithmetic expression to be evaluated.
   * @return String the expression to evaluate.
   */
  @Override
  public String getUserExpression() {
    return expressionText.getText();
  }

  /** A hook to show the user their evaluated answer.
   * @param answer the answer.
   */
  @Override
  public void setAnswer(String answer) {
    answerText.setText(answer);
  }
  
  /** A hook to show the user the type they have selected.
   * @param type the expression type.
   */
  @Override
  public void setType(String type) {
    currentMode.setText(type);
  }

  /** Add an observer of the Calculate action.
   * @param o the observer
   */
  @Override
  public void addCalcObserver(Observer o) { 
    //whenever the calcbutton gets pressed, call this function o.notifyObservers
    calcButton.setOnAction(event -> o.notifyObservers());
  }
}
