package uk.ac.rhul.cs2800;

import java.util.EmptyStackException;

/** 
 * This class creates a combined Calcualtor model which can evaluate
 * expressions in either Infix or Postfix notation by setting infix to true or false.
 *  
 * @author Zayad Khan
 *
 */
public class CalcModel {
  /**
   * The RPN calculator which evaluates Postfix Notation expressions.
   */
  private Calculator rvpCalc = new RevPolishCalc();
  /**
   *  The Standard Calculator which evaluates Infix Notation expressions.
   */
  private Calculator sdCalc = new StandardCalc();
  
  /**
   * Evaluate an Infix or Postfix expression.
   * @param expr the expression.
   * @param infix infix or not infix.
   * @return float the answer.
   * @throws EmptyStackException If the expression has no elements.
   * @throws InvalidExpression If the expression passed is Invalid.
   * @throws BadTypeException If the expression passed is not a String.
   */
  public float evaluate(String expr, boolean infix) 
      throws EmptyStackException, InvalidExpression, BadTypeException {
    if (infix) {
      return sdCalc.evaluate(expr);
    } else if (!infix) {
      return rvpCalc.evaluate(expr);
    } else {
      throw new InvalidExpression();
    }
  }
}
