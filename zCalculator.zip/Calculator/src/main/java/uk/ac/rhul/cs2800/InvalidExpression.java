package uk.ac.rhul.cs2800;

/** This class is for defining a custom exception.
 * @author Zayad Khan
 *
 */
public class InvalidExpression extends Exception {
  
  /** Construct a new InvalidExpression exception.
   * Display error message.
   */
  public InvalidExpression() {
    super("This Expression is Invalid.");
  }
}
